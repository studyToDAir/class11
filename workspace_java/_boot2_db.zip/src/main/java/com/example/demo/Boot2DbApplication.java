package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot2DbApplication {

	public static void main(String[] args) {
		SpringApplication.run(Boot2DbApplication.class, args);
	}

}
